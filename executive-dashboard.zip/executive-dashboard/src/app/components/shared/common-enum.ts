export enum DateRangeTypes{
    ThisMonth = 0,
    LastMonth = 1,
    YearToDate = 2,
    CustomRange = 3
}